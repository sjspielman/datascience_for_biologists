food <- "eucalyptus leaves"
habitat <- "trees"

# paste0() is like paste(), but doesn't add a space between strings we're combining
phrase <- paste0("Koalas eat ", food, ", and they live in ", habitat, ".")

print(phrase)
