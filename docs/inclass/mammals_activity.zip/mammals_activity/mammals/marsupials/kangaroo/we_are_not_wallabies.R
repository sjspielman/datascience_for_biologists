print('Kangaroos are not wallabies!')
