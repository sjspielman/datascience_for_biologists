monotreme_group1 <- "platypus"
monotreme_group2 <- "echinda"

all_groups <- c(monotreme_group1, monotreme_group2)
print(paste("Groups of monotremes are still alive are:", all_groups))